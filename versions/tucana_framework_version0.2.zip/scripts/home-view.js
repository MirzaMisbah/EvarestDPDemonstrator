window.addEventListener('load', function (event) {

    // Add frontend objects to app object
    app.loadingSpinner = document.getElementById('spinner');
    app.mainContainer = document.querySelector('main');
    app.notificationSnackbar = document.querySelector('#notificationbar');
    app.visitAppStoreButton = document.querySelector('#visit');

    // Initialization of all important objects of included scripts
    var crossDataStorageClient = new CrossDataStorageClient(app.localStorageCenter);
    var authorizationManager = new Auth0Configurator(app.oauthClientId, app.oauthDomainName);
    var visalizationService = new VisualizationService('testChartContainer', Highcharts);

    // initialization function of the app shell
    app.init = function () {

        // Start the authorization service
        authorizationManager.connect('btn-logout', 'username', function () {
            // Initialize important frontend properties
            app.changeLoadingStatus();
            app.visitAppStoreButton.href = app.localStorageCenter;

            // TODO Insert visualiuation and analysis functions
        });
    };

    // Run the application with current settings
    app.init();
});