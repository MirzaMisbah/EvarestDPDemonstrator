'use strict';

(function (root) {

    var app = {
        // URL's of generic service for heartrate and step data used for synchronization
        syncApiAdress : 'http://iot01.iss.uni-saarland.de:81',
        syncHeartrateExtension : '/genericHeartRateService',
        syncStepExtension : '/genericStepDataService',

        // Location of the local storage center
        localStorageCenter : 'http://localhost:3000',

        // OAuth 2.0 variables
        oauthClientId : 'kMlSIl3Itqt6mQetzGXES6biAVFei6k8',
        oauthDomainName : 'app-iss.eu.auth0.com',

        loaded : false
    };

    app.showNotification = function (message, duration) {
        if (!message) {
            return;
        }
        if (!duration) {
            duration = 2000;
        }
        const data = {message: message, timeout: duration};
        app.notificationSnackbar.MaterialSnackbar.showSnackbar(data);
    };

    app.changeLoadingStatus = function () {
        app.loaded = !app.loaded;
        if (app.loaded) {
            app.mainContainer.style.visibility = 'visible';
            app.loadingSpinner.style.visibility = 'hidden';
        } else {
            app.mainContainer.style.visibility = 'hidden';
            app.loadingSpinner.style.visibility = 'visible';
        }
    };

    /*
    Export the module for various environments.
     */
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = app;
    } else if (typeof exports !== 'undefined') {
        exports.app = app;
    } else if (typeof define === 'function' && define.amd) {
        define([], function () {
            return app;
        });
    } else {
        root.app = app;
    }
}(this));